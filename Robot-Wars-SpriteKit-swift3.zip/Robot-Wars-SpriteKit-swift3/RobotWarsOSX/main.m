//
//  main.m
//  RobotWarsOSX
//
//  Created by Dion Larson on 6/4/16.
//  Copyright © 2016 Make School. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}

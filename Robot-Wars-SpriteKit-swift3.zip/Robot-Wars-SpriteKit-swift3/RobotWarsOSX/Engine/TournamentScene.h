//
//  TourneyManagementScene.h
//  RobotWar
//
//  Created by Daniel Haaser on 7/5/14.
//  Copyright (c) 2014 Make School. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface TournamentScene : SKScene

- (void)updateWithResults:(NSDictionary*)results;

@end

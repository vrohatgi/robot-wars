//
//  TournamentConfiguration.h
//  RobotWar
//
//  Created by Daniel Haaser on 7/8/14.
//  Copyright (c) 2014 Make School. All rights reserved.
//

#ifndef RobotWar_TournamentConfiguration_h
#define RobotWar_TournamentConfiguration_h

static const int COUNTDOWN = 5;
static const BOOL TOURNAMENT = NO;

#endif
